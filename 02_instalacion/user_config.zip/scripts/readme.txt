﻿All the scripts in this folder are under the GPLv3 license.
https://www.gnu.org/licenses/gpl-3.0.en.html

Copyright (c) 2011-2018 Briac PilPré, Didier Briel, Yu Tang, Kos Ivantsov, Piotr Kulik

References:
OmegaT Javadoc: https://omegat.sourceforge.io/javadoc-latest/
Groovy 2.4.10 language reference: http://groovy-lang.org/single-page-documentation.html
ECMAScript 262 Language Specification: https://www.ecma-international.org/ecma-262/5.1/
